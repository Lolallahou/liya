import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Product } from "@shared/schema";
import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import CategoryCard from "@/components/category-card";
import ProductCard from "@/components/product-card";
import PostAdModal from "@/components/post-ad-modal";
import ProductDetailModal from "@/components/product-detail-modal";
import Footer from "@/components/footer";

const categories = [
  { name: "Électronique", color: "emerald", icon: "📱" },
  { name: "Immobilier", color: "blue", icon: "🏠" },
  { name: "Véhicules", color: "red", icon: "🚗" },
  { name: "Mode", color: "purple", icon: "👗" },
  { name: "Maison & Jardin", color: "green", icon: "🏡" },
  { name: "Loisirs", color: "yellow", icon: "🎮" },
];

export default function Home() {
  const [isPostAdModalOpen, setIsPostAdModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: products = [], isLoading, refetch } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const filteredProducts = products.filter((product) => {
    const matchesSearch = searchQuery === "" || 
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === null || product.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setSelectedCategory(null);
  };

  const handleCategoryFilter = (category: string) => {
    setSelectedCategory(selectedCategory === category ? null : category);
    setSearchQuery("");
  };

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
  };

  const handlePostAdSuccess = () => {
    refetch();
    setIsPostAdModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 font-['Poppins']">
      <Header 
        onPostAdClick={() => setIsPostAdModalOpen(true)}
        onSearch={handleSearch}
        searchQuery={searchQuery}
      />
      
      <HeroSection onPostAdClick={() => setIsPostAdModalOpen(true)} />

      {/* Categories Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-center mb-8 text-gray-800">
            Parcourir par catégorie
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <CategoryCard
                key={category.name}
                name={category.name}
                color={category.color}
                icon={category.icon}
                isSelected={selectedCategory === category.name}
                onClick={() => handleCategoryFilter(category.name)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Filter Bar */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <h2 className="text-2xl font-bold text-gray-800">
              {selectedCategory ? `Catégorie: ${selectedCategory}` : 
               searchQuery ? `Résultats pour: "${searchQuery}"` : 
               "Annonces récentes"}
            </h2>
            <div className="flex flex-col sm:flex-row gap-3">
              {(selectedCategory || searchQuery) && (
                <button
                  onClick={() => {
                    setSelectedCategory(null);
                    setSearchQuery("");
                  }}
                  className="px-4 py-2 text-emerald-600 border border-emerald-500 rounded-lg hover:bg-emerald-50 transition-colors"
                >
                  Voir tout
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Product Grid */}
        <section>
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow-sm overflow-hidden animate-pulse">
                  <div className="w-full h-48 bg-gray-200"></div>
                  <div className="p-5">
                    <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-8 bg-gray-200 rounded w-1/2 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg mb-4">
                {searchQuery || selectedCategory 
                  ? "Aucune annonce trouvée pour vos critères de recherche."
                  : "Aucune annonce pour le moment."
                }
              </p>
              <button
                onClick={() => setIsPostAdModalOpen(true)}
                className="btn-primary font-semibold px-6 py-3 rounded-full shadow-lg"
              >
                Soyez le premier à publier une annonce !
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onClick={() => handleProductClick(product)}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* CTA Section */}
      <section className="hero-gradient text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Prêt à vendre ?</h2>
          <p className="text-xl mb-8 text-emerald-100 max-w-2xl mx-auto">
            Rejoignez des milliers de vendeurs qui font confiance à Liya pour leurs transactions.
          </p>
          <button
            onClick={() => setIsPostAdModalOpen(true)}
            className="bg-white text-emerald-600 font-semibold px-8 py-4 rounded-full hover:bg-emerald-50 transition-all duration-300 shadow-lg"
          >
            Commencer maintenant
          </button>
        </div>
      </section>

      <Footer />

      <PostAdModal
        isOpen={isPostAdModalOpen}
        onClose={() => setIsPostAdModalOpen(false)}
        onSuccess={handlePostAdSuccess}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
      />
    </div>
  );
}
