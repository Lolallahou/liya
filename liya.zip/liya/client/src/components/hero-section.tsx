interface HeroSectionProps {
  onPostAdClick: () => void;
}

export default function HeroSection({ onPostAdClick }: HeroSectionProps) {
  return (
    <section className="hero-gradient text-white py-16">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Votre marché local en ligne
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-emerald-50 max-w-3xl mx-auto">
          Achetez et vendez facilement dans votre région. Des milliers de produits vous attendent.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="bg-white text-emerald-600 font-semibold px-8 py-4 rounded-full hover:bg-emerald-50 transition-all duration-300 shadow-lg">
            Explorer les annonces
          </button>
          <button
            onClick={onPostAdClick}
            className="border-2 border-white text-white font-semibold px-8 py-4 rounded-full hover:bg-white hover:text-emerald-600 transition-all duration-300"
          >
            Commencer à vendre
          </button>
        </div>
      </div>
    </section>
  );
}
