interface CategoryCardProps {
  name: string;
  color: string;
  icon: string;
  isSelected: boolean;
  onClick: () => void;
}

export default function CategoryCard({ name, color, icon, isSelected, onClick }: CategoryCardProps) {
  const getColorClasses = (color: string) => {
    const colorMap = {
      emerald: isSelected ? "bg-emerald-200" : "bg-emerald-50 hover:bg-emerald-100",
      blue: isSelected ? "bg-blue-200" : "bg-blue-50 hover:bg-blue-100",
      red: isSelected ? "bg-red-200" : "bg-red-50 hover:bg-red-100",
      purple: isSelected ? "bg-purple-200" : "bg-purple-50 hover:bg-purple-100",
      green: isSelected ? "bg-green-200" : "bg-green-50 hover:bg-green-100",
      yellow: isSelected ? "bg-yellow-200" : "bg-yellow-50 hover:bg-yellow-100",
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.emerald;
  };

  const getIconColorClasses = (color: string) => {
    const colorMap = {
      emerald: "bg-emerald-500",
      blue: "bg-blue-500",
      red: "bg-red-500",
      purple: "bg-purple-500",
      green: "bg-green-500",
      yellow: "bg-yellow-500",
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.emerald;
  };

  return (
    <div
      className={`${getColorClasses(color)} rounded-xl p-6 text-center transition-colors cursor-pointer ${
        isSelected ? 'ring-2 ring-emerald-500' : ''
      }`}
      onClick={onClick}
    >
      <div className={`w-12 h-12 ${getIconColorClasses(color)} rounded-full mx-auto mb-3 flex items-center justify-center text-white text-xl`}>
        {icon}
      </div>
      <p className="font-medium text-gray-800">{name}</p>
    </div>
  );
}
