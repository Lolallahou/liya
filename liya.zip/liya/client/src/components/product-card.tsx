import type { Product } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

interface ProductCardProps {
  product: Product;
  onClick: () => void;
}

export default function ProductCard({ product, onClick }: ProductCardProps) {
  const getCategoryColor = (category: string) => {
    const colorMap = {
      "Électronique": "bg-gray-100 text-gray-700",
      "Immobilier": "bg-blue-100 text-blue-700",
      "Véhicules": "bg-red-100 text-red-700",
      "Mode": "bg-purple-100 text-purple-700",
      "Maison & Jardin": "bg-green-100 text-green-700",
      "Loisirs": "bg-yellow-100 text-yellow-700",
    };
    return colorMap[category as keyof typeof colorMap] || "bg-gray-100 text-gray-700";
  };

  const timeAgo = formatDistanceToNow(new Date(product.createdAt), {
    addSuffix: true,
    locale: fr,
  });

  return (
    <div
      className="product-card bg-white rounded-xl shadow-sm overflow-hidden cursor-pointer"
      onClick={onClick}
    >
      <img
        src={product.imageUrl}
        alt={product.title}
        className="w-full h-48 object-cover"
        onError={(e) => {
          const target = e.target as HTMLImageElement;
          target.src = "https://placehold.co/600x400/e2e8f0/94a3b8?text=Image+Indisponible";
        }}
      />
      <div className="p-5">
        <h3 className="font-semibold text-lg text-gray-800 mb-2 line-clamp-2">
          {product.title}
        </h3>
        <p className="text-2xl font-bold text-emerald-600 mb-2">
          {product.price.toLocaleString()} F
        </p>
        <div className="flex items-center justify-between text-sm text-gray-500">
          <span className={`px-3 py-1 rounded-full ${getCategoryColor(product.category)}`}>
            {product.category}
          </span>
          <span>{timeAgo}</span>
        </div>
      </div>
    </div>
  );
}
