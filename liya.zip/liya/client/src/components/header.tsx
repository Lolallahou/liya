import { Search, Plus } from "lucide-react";

interface HeaderProps {
  onPostAdClick: () => void;
  onSearch: (query: string) => void;
  searchQuery: string;
}

export default function Header({ onPostAdClick, onSearch, searchQuery }: HeaderProps) {
  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="logo">Liya</div>
          <span className="text-xs text-gray-500 hidden sm:block">Marché Africain</span>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Desktop Search */}
          <div className="hidden md:flex items-center relative">
            <input
              type="text"
              placeholder="Rechercher un produit..."
              value={searchQuery}
              onChange={(e) => onSearch(e.target.value)}
              className="pl-10 pr-4 py-3 w-80 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-gray-50"
            />
            <Search className="absolute left-3 w-5 h-5 text-gray-400" />
          </div>
          
          <button
            onClick={onPostAdClick}
            className="btn-primary font-semibold px-6 py-3 rounded-full shadow-lg flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span className="hidden sm:inline">Déposer une annonce</span>
            <span className="sm:hidden">Vendre</span>
          </button>
        </div>
      </nav>
      
      {/* Mobile Search */}
      <div className="md:hidden px-4 pb-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Rechercher un produit..."
            value={searchQuery}
            onChange={(e) => onSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-gray-50"
          />
          <Search className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
        </div>
      </div>
    </header>
  );
}
