import { X } from "lucide-react";
import type { Product } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
}

export default function ProductDetailModal({ product, onClose }: ProductDetailModalProps) {
  if (!product) return null;

  const timeAgo = formatDistanceToNow(new Date(product.createdAt), {
    addSuffix: true,
    locale: fr,
  });

  const getCategoryColor = (category: string) => {
    const colorMap = {
      "Électronique": "bg-gray-100 text-gray-700",
      "Immobilier": "bg-blue-100 text-blue-700",
      "Véhicules": "bg-red-100 text-red-700",
      "Mode": "bg-purple-100 text-purple-700",
      "Maison & Jardin": "bg-green-100 text-green-700",
      "Loisirs": "bg-yellow-100 text-yellow-700",
    };
    return colorMap[category as keyof typeof colorMap] || "bg-gray-100 text-gray-700";
  };

  return (
    <div className="modal fixed inset-0 bg-black bg-opacity-50 backdrop-blur flex justify-center items-center p-4 z-50">
      <div className="modal-content bg-white rounded-2xl shadow-2xl w-full max-w-4xl transform scale-100 overflow-hidden max-h-[90vh] overflow-y-auto">
        <div className="relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 bg-white rounded-full p-2 shadow-lg hover:bg-gray-50 transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
          
          <div className="grid grid-cols-1 lg:grid-cols-2">
            {/* Image Section */}
            <div className="aspect-square lg:aspect-auto">
              <img
                src={product.imageUrl}
                alt={product.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = "https://placehold.co/600x400/e2e8f0/94a3b8?text=Image+Indisponible";
                }}
              />
            </div>

            {/* Details Section */}
            <div className="p-8">
              <div className="mb-4">
                <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(product.category)}`}>
                  {product.category}
                </span>
              </div>

              <h1 className="text-3xl font-bold text-gray-800 mb-4">
                {product.title}
              </h1>

              <div className="text-4xl font-bold text-emerald-600 mb-6">
                {product.price.toLocaleString()} F CFA
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Description</h3>
                <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">
                  {product.description}
                </p>
              </div>

              <div className="mb-8">
                <p className="text-sm text-gray-500">
                  Publié {timeAgo}
                </p>
              </div>

              <div className="space-y-3">
                <button className="w-full btn-primary font-semibold py-4 rounded-xl shadow-lg text-lg">
                  Contacter le vendeur
                </button>
                <button className="w-full border-2 border-emerald-500 text-emerald-600 font-semibold py-4 rounded-xl hover:bg-emerald-50 transition-colors">
                  Envoyer un message
                </button>
              </div>

              <div className="mt-6 p-4 bg-gray-50 rounded-xl">
                <h4 className="font-semibold text-gray-800 mb-2">Conseils de sécurité</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Rencontrez le vendeur dans un lieu public</li>
                  <li>• Vérifiez l'article avant d'acheter</li>
                  <li>• Ne payez jamais à l'avance</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
